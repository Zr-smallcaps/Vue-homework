<template>
  <div>
    <router-link to="/Page">首页</router-link>
    <router-link to="/sort">分类</router-link>
    <router-link to="/order">订单</router-link>
    <router-link to="/my">我的</router-link>
    <h2>
      显示路由切换的页面！
    </h2>
    <router-view></router-view>
  </div>
  
</template>

<script>
export default {
   
}
</script>

<style>

</style>