<template>
  <div>
       <div>
 <router-link to="/my/Mytwo">我是二级镶套</router-link>
 <router-link to="/my/Mytwo">我是二级镶套</router-link>
    </div>
   
      <div>
    <router-view></router-view>
  </div>
  </div>
</template>

<script>
export default {

}
</script>

<style>

</style>