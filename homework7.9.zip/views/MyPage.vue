<template>
  <div>
     <h3>首页新闻</h3>
    <h3>首页活动</h3>
  </div>
</template>

<script>
export default {

}
</script>

<style>

</style>