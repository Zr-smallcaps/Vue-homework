<template>
  <div>
    <h3>动漫</h3>
    <h3>卡卡西</h3>
  </div>
</template>

<script>
export default {

}
</script>

<style>

</style>