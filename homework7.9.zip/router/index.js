import Vue from 'vue'
import VueRouter from 'vue-router'
import  Page from "@/views/MyPage";
import  Sort from "@/views/MySort";
import  Order from "@/views/MyOrder";
import  My from "@/views/MyMine";
import MyTwo from '@/TwoViews/MyTwo1';
Vue.use(VueRouter)

const routes = [
    {
        path: '/',
        redirect: "/Page"
    },
    {
        path: "/page",
        component: Page
    },
    {
        path: "/sort",
        component: Sort
    },
    {
        path: "/order",
        component: Order
    },
    {
        path: "/my",
        component: My,
        children: [
            {
            path:'Mytwo',
            component: MyTwo
        }
    ]
    }
]

const router = new VueRouter({
    routes
})
console.log(router);
export default router