<template>
  <div>
    <van-nav-bar
  :title="title"
  class="pink"
/>
 <router-view></router-view>

 <van-tabbar route>
  <van-tabbar-item icon="home-o" to="/layout/home">宇哥</van-tabbar-item>
  <van-tabbar-item icon="search" to="/layout/search">威武</van-tabbar-item>
</van-tabbar>
  </div>
</template>

<script>
export default {
    data() {
        return {
           title: "媛媛的歌单"
        }
    },
  methods: {
  },
  watch:{
    $route(newval){
        this.title=newval.meta.title
    }
  },
//   mounted(){
//     this.title=this.$route.meta.title
//   },

}
</script>

<style>
.pink{
  background-color: pink;
}
</style>