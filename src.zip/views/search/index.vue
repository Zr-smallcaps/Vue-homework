
<template>
  <div class="search-container">
    <van-search
      shape="round"
      placeholder="请输入搜索关键词"
      v-model.trim="value"
    />
    <!-- 热门搜索 -->
       <!-- 热门搜索 -->
 <van-cell title="热门搜索" />
    <div style="padding: 5px 10px">
      <van-tag color="#ccc"  text-color="#000" size="large" plain  round  type="primary"  v-for="(item, index) in tags"  :key="index"  style="margin-right: 6px"  @click="clickFn(item.first)">
        {{ item.first }}
      </van-tag>
    </div>
    <template >
      <!-- 最佳匹配 -->
      <van-cell title="最佳匹配" />
      <van-list v-model="loading" :finished="finished" finished-text="没有更多了" @load="onLoad" >
        <van-cell v-for="item in searchList" :key="item.id" :title="item.name" />
      </van-list>
    </template>
      </div>

</template>
<script>
import {getSearchListAPI,getSearchList2API} from '@/apis'
export default {
  data() {
    return {
      tags:[],
      value:'',
      searchList:'',
      finished:false,
      loading:false
    }
  },
  created(){
   this.getSearchList()
  },
  methods:{   
    async getSearchList(){
        try{
          const res=await getSearchListAPI({ 
          });
          console.log(res);
          this.tags = res.data.result.hots;
        }catch(e){
          console.log('e',e);
        }
      },
     async clickFn(val){
        this.value = val //赋值给表单
        const res=await getSearchList2API({ 
          keywords: this.value,
          });
          // console.log(res);
          this.searchList = res.data.result.songs;
        },
        onLoad(){}
      }
  }


</script>

<style>
.main {
  padding-top: 46px;
  padding-bottom: 50px;
}
</style>

