<template>
  <div>
    
    <router-view></router-view>
    <!-- <router-link to="/layout">hh</router-link> -->
  </div>
</template>

<script>
export default {
  data() {
    return {
      
    }
  },
}
</script>

<style>

</style>