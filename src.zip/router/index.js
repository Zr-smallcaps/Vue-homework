import Vue from 'vue'
import VueRouter from 'vue-router'
import Layout from '@/views/Layout'
import Home from '@/views/Home/'
import Search from '@/views/search'

Vue.use(VueRouter)

const routes=[
    {
        path: '/',
        redirect: '/layout/home',
    },
    {
        path: '/layout',
        component: Layout,
        children:[
            {
                path: 'home',
                component: Home,
                meta:{
                    title: '媛媛的歌单'
                }
            },
            {
                path: 'search',
                component: Search,
                meta:{
                    title: '媛媛的歌单'
                }
            }
        ]
    }
]

const router=new VueRouter({
    routes
})
export default router