import Vue from 'vue'
import App from './App.vue'
import '@/assets/styles/reset.css'
import '@/assets/mobile/flexible'
Vue.config.productionTip = false
import router from '@/router'


import { Tabbar, TabbarItem, Col, Row, Cell, CellGroup, Icon ,Tag,Toast } from 'vant';
import { NavBar } from 'vant';

import { Image as VanImage } from 'vant';
import { Search } from 'vant'; 
Vue.use(Search);
import { List } from 'vant'; Vue.use(List);

Vue.use(VanImage);
Vue.use(Col);
Vue.use(Row);
Vue.use(Cell);
Vue.use(CellGroup);
Vue.use(Icon);
Vue.use(NavBar);
Vue.use(Tabbar);
Vue.use(TabbarItem);
Vue.use(Icon);
Vue.use(Tag);
Vue.use(Toast);




//演示接口的用法 
import {getRecommendedListAPI} from  '@/apis'
console.log(getRecommendedListAPI());



new Vue({
  router,
  render: h => h(App),
  
}).$mount('#app')
