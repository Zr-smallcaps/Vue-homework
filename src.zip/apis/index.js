import {getRecommendedList} from './home'
import {getNewSongList} from './home'
import {getSearchList} from './search'
import {getSearchList2} from './search'

 export const  getRecommendedListAPI = getRecommendedList;
 export const  getNewSongListAPI = getNewSongList;
 export const  getSearchListAPI = getSearchList;
 export const  getSearchList2API = getSearchList2;