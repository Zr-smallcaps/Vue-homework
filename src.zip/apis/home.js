//和home相关的接口
import request from '@/utils/request'

export const getRecommendedList=(params) =>
request({
        url: '/personalized',
        params// 将来外面可能传入params的值
}) 

export const getNewSongList=(params) =>
request({
        url: '/personalized/newsong',
        params// 将来外面可能传入params的值
}) 

