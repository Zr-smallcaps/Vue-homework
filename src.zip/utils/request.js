//对axios 的封装
import axios from 'axios'

const request = axios.create({
    baseURL: 'http://43.142.37.253:8080/'
}
  
)
export default request